import React from 'react';
import { ExchangeProvider, useExchange } from './context/ExchangeContext';
import { Navbar } from './components/Navbar';
import { Hero3D } from './components/Hero3D';
import { CategoryFilterBar } from './components/CategoryFilterBar';
import { PublicationCard } from './components/PublicationCard';
import { PublicationDetailModal } from './components/PublicationDetailModal';
import { CreatePublicationModal } from './components/CreatePublicationModal';
import { ContactExchangeModal } from './components/ContactExchangeModal';
import { RequestsDrawer } from './components/RequestsDrawer';
import { AdminPanelModal } from './components/AdminPanelModal';
import { ProjectInfoModal } from './components/ProjectInfoModal';
import { AuthModal } from './components/AuthModal';
import { Footer } from './components/Footer';
import { filterPublications } from './utils/exchangeLogic';
import {
  Sparkles,
  BookOpen,
  ArrowRight,
  Star,
} from 'lucide-react';

const ExchangePortal: React.FC = () => {
  const {
    publications,
    filter,
    setFilter,
    setIsCreateModalOpen,
    setIsProjectInfoModalOpen,
    isLoggedIn,
    setIsAuthModalOpen,
  } = useExchange();

  const filteredPubs = filterPublications(publications, filter);

  const hasActiveFilters =
    filter.category !== 'todas' ||
    filter.career !== 'todas' ||
    filter.campus !== 'todos' ||
    filter.minRating > 0 ||
    filter.searchQuery.trim() !== '';

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans selection:bg-red-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Unified Hero Section with Official UCV Logo */}
        <Hero3D />

        {/* Categories & Careers Filter Bar */}
        <CategoryFilterBar />

        {/* Results Counter & Active Filters Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600" />
            <h2 className="font-bold text-slate-900 text-sm sm:text-base">
              Catálogo de Intercambio Académico Nacional
            </h2>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
              {filteredPubs.length} disponibles
            </span>
          </div>

          {hasActiveFilters && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-slate-500 font-medium">Filtros:</span>
              {filter.category !== 'todas' && (
                <span className="text-xs bg-red-50 text-red-700 px-2 py-0.5 rounded-md font-semibold border border-red-200">
                  {filter.category}
                </span>
              )}
              {filter.career !== 'todas' && (
                <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-semibold border border-slate-200">
                  {filter.career}
                </span>
              )}
              {filter.campus !== 'todos' && (
                <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-semibold border border-slate-200">
                  Sede {filter.campus}
                </span>
              )}
              {filter.searchQuery && (
                <span className="text-xs bg-amber-50 text-amber-800 px-2 py-0.5 rounded-md font-semibold border border-amber-200">
                  "{filter.searchQuery}"
                </span>
              )}
              <button
                type="button"
                onClick={() =>
                  setFilter({
                    category: 'todas',
                    career: 'todas',
                    campus: 'todos',
                    searchQuery: '',
                    sortBy: 'relevance',
                    minRating: 0,
                  })
                }
                className="text-xs text-red-600 font-bold hover:underline ml-1"
              >
                Limpiar todo
              </button>
            </div>
          )}
        </div>

        {/* Publications Grid */}
        {filteredPubs.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4 max-w-lg mx-auto shadow-sm">
            <div className="w-16 h-16 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto">
              <BookOpen className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-900 text-lg">No encontramos publicaciones</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              No hay recursos con los filtros seleccionados. Intenta ampliar tu búsqueda o comparte el primer material para tus compañeros.
            </p>
            <div className="flex justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() =>
                  setFilter({
                    category: 'todas',
                    career: 'todas',
                    campus: 'todos',
                    searchQuery: '',
                    sortBy: 'relevance',
                    minRating: 0,
                  })
                }
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700"
              >
                Restablecer Filtros
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!isLoggedIn) {
                    setIsAuthModalOpen(true);
                  } else {
                    setIsCreateModalOpen(true);
                  }
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-700 text-white shadow"
              >
                + Publicar Ahora
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPubs.map((pub) => (
              <PublicationCard key={pub.id} publication={pub} />
            ))}
          </div>
        )}

        {/* Real Cases & Community Testimonials Section */}
        <section className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-5">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-red-600">
                Experiencias y Casos Reales UCV
              </span>
              <h3 className="text-xl font-extrabold text-slate-900">
                Colaboración Universitaria Verificada a Nivel Nacional
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setIsProjectInfoModalOpen(true)}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-red-600 hover:text-red-700 hover:underline"
            >
              Leer fundamento del proyecto <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Real Case 1 */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-red-50/30 border border-slate-200/90 space-y-3">
              <div className="flex items-center text-amber-400">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                "Los apuntes de cálculo y diseño estructural de Michael Delgado me permitieron preparar mi sustento en Estructuras I sin depender de fotocopias dispersas."
              </p>
              <div className="pt-2 border-t border-slate-200/60 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-red-100 text-red-700 font-bold text-xs flex items-center justify-center">
                  JR
                </div>
                <div>
                  <strong className="block text-xs text-slate-900">José Roly Gonzalez</strong>
                  <span className="text-[11px] text-slate-500">Ing. Civil • UCV Trujillo</span>
                </div>
              </div>
            </div>

            {/* Real Case 2 */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-blue-50/30 border border-slate-200/90 space-y-3">
              <div className="flex items-center text-amber-400">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                "Coordinamos un equipo multidisciplinario para postular al semillero de investigación. La plataforma resuelve la dificultad para encontrar colaboradores afines."
              </p>
              <div className="pt-2 border-t border-slate-200/60 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                  MC
                </div>
                <div>
                  <strong className="block text-xs text-slate-900">Michael Grandez Acosta</strong>
                  <span className="text-[11px] text-slate-500">Ing. Civil • UCV Tarapoto</span>
                </div>
              </div>
            </div>

            {/* Real Case 3 */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-emerald-50/30 border border-slate-200/90 space-y-3">
              <div className="flex items-center text-amber-400">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                "Como catedrático asesor, destaco la incorporación de las políticas de uso responsable y respeto a los derechos de autor. Fomenta el compañerismo sin caer en el plagio."
              </p>
              <div className="pt-2 border-t border-slate-200/60 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center">
                  AT
                </div>
                <div>
                  <strong className="block text-xs text-slate-900">Ing. Alex Tongo Silva</strong>
                  <span className="text-[11px] text-slate-500">Docente Asesor • UCV Lima Norte</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer with copyright & legal information */}
      <Footer />

      {/* Modals & Drawers */}
      <PublicationDetailModal />
      <CreatePublicationModal />
      <ContactExchangeModal />
      <RequestsDrawer />
      <AdminPanelModal />
      <ProjectInfoModal />
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <ExchangeProvider>
      <ExchangePortal />
    </ExchangeProvider>
  );
}
