import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Publication,
  StudentUser,
  Review,
  ContactExchangeRequest,
  PlagiarismReport,
  FilterState,
  CategoryType,
  CareerType,
  CampusType,
} from '../types/exchange';
import {
  INITIAL_USERS,
  INITIAL_PUBLICATIONS,
  INITIAL_REQUESTS,
  INITIAL_REPORTS,
} from '../data/initialData';
import { calculateRatingDistribution } from '../utils/exchangeLogic';

interface ExchangeContextType {
  publications: Publication[];
  users: StudentUser[];
  currentUser: StudentUser | null;
  isLoggedIn: boolean;
  requests: ContactExchangeRequest[];
  reports: PlagiarismReport[];
  filter: FilterState;
  setFilter: React.Dispatch<React.SetStateAction<FilterState>>;
  selectedPublication: Publication | null;
  setSelectedPublication: (pub: Publication | null) => void;
  isCreateModalOpen: boolean;
  setIsCreateModalOpen: (open: boolean) => void;
  isContactModalOpen: boolean;
  setIsContactModalOpen: (open: boolean) => void;
  isRequestsDrawerOpen: boolean;
  setIsRequestsDrawerOpen: (open: boolean) => void;
  isAdminModalOpen: boolean;
  setIsAdminModalOpen: (open: boolean) => void;
  isProjectInfoModalOpen: boolean;
  setIsProjectInfoModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isCreatorOrAdmin: boolean;
  isOwner: boolean;
  
  // Actions
  addPublication: (data: {
    title: string;
    description: string;
    category: CategoryType;
    career: CareerType;
    course: string;
    cycleLevel: string;
    tags: string[];
    exchangeType: 'Intercambio Académico' | 'Gratuito / RSU' | 'Colaboración en Equipo';
    fileType?: 'PDF' | 'DOCX' | 'ZIP' | 'XLSX' | 'Sesión Google Meet';
    fileSize?: string;
  }) => Publication;
  updatePublicationStatus: (pubId: string, status: Publication['status']) => void;
  addReview: (publicationId: string, rating: number, comment: string) => void;
  sendContactRequest: (data: {
    publicationId: string;
    publicationTitle: string;
    publicationCategory: CategoryType;
    receiverId: string;
    receiverName: string;
    message: string;
    proposedExchange: string;
  }) => void;
  updateRequestStatus: (requestId: string, status: ContactExchangeRequest['status']) => void;
  reportPublication: (data: {
    publicationId: string;
    publicationTitle: string;
    reason: PlagiarismReport['reason'];
    details: string;
  }) => void;
  resolveReport: (reportId: string, newStatus: PlagiarismReport['status']) => void;
  loginUser: (email: string) => boolean;
  switchUser: (userId: string) => void;
  logoutUser: () => void;
  registerUser: (userData: Omit<StudentUser, 'id' | 'ratingAverage' | 'ratingCount' | 'verified'>) => StudentUser;
  createUserByAdmin: (userData: {
    name: string;
    email: string;
    role: 'student' | 'docente' | 'admin';
    career: CareerType;
    campus: CampusType;
    cycle: string;
    phone?: string;
    bio?: string;
  }) => StudentUser;
  updateUserRole: (userId: string, newRole: 'student' | 'docente' | 'admin') => void;
  deleteUser: (userId: string) => boolean;
  resetDatabase: () => void;
}

const ExchangeContext = createContext<ExchangeContextType | undefined>(undefined);

// Bumped storage keys to v3 so all previous non-Grupo 5 mock accounts are cleaned
const STORAGE_KEYS = {
  PUBLICATIONS: 'exchange_ucv_publications_v3',
  USERS: 'exchange_ucv_users_v3',
  CURRENT_USER_ID: 'exchange_ucv_current_user_v3',
  REQUESTS: 'exchange_ucv_requests_v3',
  REPORTS: 'exchange_ucv_reports_v3',
  IS_LOGGED_IN: 'exchange_ucv_is_logged_in_v3',
};

const DEFAULT_FILTER: FilterState = {
  category: 'todas',
  career: 'todas',
  searchQuery: '',
  campus: 'todos',
  sortBy: 'relevance',
  minRating: 0,
};

// Official Grupo 5 creators / owners
export const CREATOR_EMAILS = [
  'mdelgadoc@ucvvirtual.edu.pe',
  'jgonzalezg@ucvvirtual.edu.pe',
  'mgrandeza@ucvvirtual.edu.pe',
];

export const OWNER_EMAIL = 'mdelgadoc@ucvvirtual.edu.pe';

export const ExchangeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [publications, setPublications] = useState<Publication[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PUBLICATIONS);
      return saved ? JSON.parse(saved) : INITIAL_PUBLICATIONS;
    } catch {
      return INITIAL_PUBLICATIONS;
    }
  });

  // Only real verified researchers, no fictitious bots
  const [users, setUsers] = useState<StudentUser[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.USERS);
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  });

  const [currentUserId, setCurrentUserId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID);
    } catch {
      return null;
    }
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.IS_LOGGED_IN) === 'true';
    } catch {
      return false;
    }
  });

  const [requests, setRequests] = useState<ContactExchangeRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REQUESTS);
      return saved ? JSON.parse(saved) : INITIAL_REQUESTS;
    } catch {
      return INITIAL_REQUESTS;
    }
  });

  const [reports, setReports] = useState<PlagiarismReport[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.REPORTS);
      return saved ? JSON.parse(saved) : INITIAL_REPORTS;
    } catch {
      return INITIAL_REPORTS;
    }
  });

  const [filter, setFilter] = useState<FilterState>(DEFAULT_FILTER);
  const [selectedPublication, setSelectedPublication] = useState<Publication | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isRequestsDrawerOpen, setIsRequestsDrawerOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isProjectInfoModalOpen, setIsProjectInfoModalOpen] = useState(false);

  // Requirement: "al entrar la pagina debe aparecer para iniciar seccion o registrarse"
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(() => {
    // If not logged in initially, open the Auth modal on page entry
    try {
      return localStorage.getItem(STORAGE_KEYS.IS_LOGGED_IN) !== 'true';
    } catch {
      return true;
    }
  });

  // Sync state to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PUBLICATIONS, JSON.stringify(publications));
    } catch (e) {
      console.warn('LocalStorage error', e);
    }
  }, [publications]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    } catch (e) {
      console.warn('LocalStorage error', e);
    }
  }, [users]);

  useEffect(() => {
    try {
      if (currentUserId) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, currentUserId);
        localStorage.setItem(STORAGE_KEYS.IS_LOGGED_IN, 'true');
      } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_ID);
        localStorage.setItem(STORAGE_KEYS.IS_LOGGED_IN, 'false');
      }
    } catch (e) {
      console.warn('LocalStorage error', e);
    }
  }, [currentUserId, isLoggedIn]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(requests));
    } catch (e) {
      console.warn('LocalStorage error', e);
    }
  }, [requests]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));
    } catch (e) {
      console.warn('LocalStorage error', e);
    }
  }, [reports]);

  // Keep selectedPublication updated
  useEffect(() => {
    if (selectedPublication) {
      const updated = publications.find((p) => p.id === selectedPublication.id);
      if (updated) {
        setSelectedPublication(updated);
      }
    }
  }, [publications]);

  const currentUser = users.find((u) => u.id === currentUserId) || null;

  const isCreatorOrAdmin = Boolean(
    currentUser && (
      currentUser.role === 'admin' ||
      CREATOR_EMAILS.includes(currentUser.email.toLowerCase().trim())
    )
  );

  const isOwner = Boolean(
    currentUser && currentUser.email.toLowerCase().trim() === OWNER_EMAIL
  );

  const loginUser = (email: string): boolean => {
    const raw = email.toLowerCase().trim();
    let targetEmail = raw;
    if (raw === 'admin' || raw === 'delgado' || raw === 'michael') targetEmail = 'mdelgadoc@ucvvirtual.edu.pe';
    else if (raw === 'gonzalez' || raw === 'roly') targetEmail = 'jgonzalezg@ucvvirtual.edu.pe';
    else if (raw === 'grandez' || raw === 'cristofer') targetEmail = 'mgrandeza@ucvvirtual.edu.pe';

    const found = users.find((u) => u.email.toLowerCase().trim() === targetEmail);
    if (found) {
      setCurrentUserId(found.id);
      setIsLoggedIn(true);
      setIsAuthModalOpen(false);
      try {
        confetti({ particleCount: 50, spread: 50 });
      } catch {}
      return true;
    }
    return false;
  };

  const createUserByAdmin = (userData: {
    name: string;
    email: string;
    role: 'student' | 'docente' | 'admin';
    career: CareerType;
    campus: CampusType;
    cycle: string;
    phone?: string;
    bio?: string;
  }): StudentUser => {
    const avatarChoice =
      userData.role === 'docente'
        ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=250&q=80'
        : userData.role === 'admin'
        ? 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=250&q=80'
        : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80';

    const newUser: StudentUser = {
      id: `u-${Date.now()}`,
      name: userData.name.trim(),
      email: userData.email.trim().toLowerCase(),
      role: userData.role,
      career: userData.career,
      campus: userData.campus,
      cycle: userData.cycle || (userData.role === 'docente' ? 'Catedrático' : 'Ciclo I'),
      avatar: avatarChoice,
      verified: true,
      ratingAverage: 5.0,
      ratingCount: 0,
      bio:
        userData.bio?.trim() ||
        `${userData.role === 'docente' ? 'Docente' : userData.role === 'admin' ? 'Administrador' : 'Estudiante'} de ${userData.career} - Sede ${userData.campus}.`,
      phone: userData.phone?.trim() || '+51 900 000 000',
    };

    setUsers((prev) => [...prev, newUser]);
    try {
      confetti({ particleCount: 60, spread: 55 });
    } catch {}
    return newUser;
  };

  const updateUserRole = (userId: string, newRole: 'student' | 'docente' | 'admin') => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          // Cannot demote root Grupo 5 founders
          if (CREATOR_EMAILS.includes(u.email.toLowerCase().trim())) {
            return u;
          }
          return { ...u, role: newRole };
        }
        return u;
      })
    );
  };

  const deleteUser = (userId: string): boolean => {
    const target = users.find((u) => u.id === userId);
    if (!target) return false;
    if (CREATOR_EMAILS.includes(target.email.toLowerCase().trim())) {
      return false; // Cannot delete Grupo 5 founders
    }
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    return true;
  };

  const switchUser = (userId: string) => {
    const found = users.find((u) => u.id === userId);
    if (found) {
      setCurrentUserId(found.id);
      setIsLoggedIn(true);
      setIsAuthModalOpen(false);
    }
  };

  const logoutUser = () => {
    setCurrentUserId(null);
    setIsLoggedIn(false);
    setIsAuthModalOpen(true);
  };

  const registerUser = (
    userData: Omit<StudentUser, 'id' | 'ratingAverage' | 'ratingCount' | 'verified'>
  ): StudentUser => {
    const newUser: StudentUser = {
      ...userData,
      id: `u-${Date.now()}`,
      verified: true,
      ratingAverage: 5.0,
      ratingCount: 0,
      avatar:
        userData.avatar ||
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80',
    };

    setUsers((prev) => [newUser, ...prev]);
    setCurrentUserId(newUser.id);
    setIsLoggedIn(true);
    setIsAuthModalOpen(false);

    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {}

    return newUser;
  };

  const addPublication = (data: {
    title: string;
    description: string;
    category: CategoryType;
    career: CareerType;
    course: string;
    cycleLevel: string;
    tags: string[];
    exchangeType: 'Intercambio Académico' | 'Gratuito / RSU' | 'Colaboración en Equipo';
    fileType?: 'PDF' | 'DOCX' | 'ZIP' | 'XLSX' | 'Sesión Google Meet';
    fileSize?: string;
  }): Publication => {
    const authorToUse = currentUser || INITIAL_USERS[0];
    const newPub: Publication = {
      id: `pub-${Date.now()}`,
      title: data.title,
      description: data.description,
      category: data.category,
      career: data.career,
      course: data.course,
      author: authorToUse,
      cycleLevel: data.cycleLevel,
      tags: data.tags,
      exchangeType: data.exchangeType,
      fileType: data.fileType || 'PDF',
      fileSize: data.fileSize || '3.5 MB',
      downloadCount: 1,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'aprobado',
      ratingAverage: 5.0,
      ratingCount: 0,
      reviews: [],
      contactCount: 0,
    };

    setPublications((prev) => [newPub, ...prev]);
    try {
      confetti({
        particleCount: 80,
        spread: 60,
      });
    } catch {}
    return newPub;
  };

  const updatePublicationStatus = (pubId: string, status: Publication['status']) => {
    setPublications((prev) =>
      prev.map((p) => (p.id === pubId ? { ...p, status } : p))
    );
  };

  const addReview = (publicationId: string, rating: number, comment: string) => {
    const reviewer = currentUser || INITIAL_USERS[0];
    const newReview: Review = {
      id: `rev-${Date.now()}`,
      publicationId,
      authorId: reviewer.id,
      authorName: reviewer.name,
      authorAvatar: reviewer.avatar,
      authorCareer: reviewer.career,
      rating: Math.min(5, Math.max(1, rating)),
      comment,
      createdAt: new Date().toISOString().split('T')[0],
      verifiedExchange: true,
    };

    setPublications((prev) =>
      prev.map((pub) => {
        if (pub.id !== publicationId) return pub;
        const updatedReviews = [newReview, ...pub.reviews];
        const stats = calculateRatingDistribution(updatedReviews);
        return {
          ...pub,
          reviews: updatedReviews,
          ratingAverage: stats.average,
          ratingCount: stats.total,
        };
      })
    );

    try {
      confetti({ particleCount: 50, spread: 45 });
    } catch {}
  };

  const sendContactRequest = (data: {
    publicationId: string;
    publicationTitle: string;
    publicationCategory: CategoryType;
    receiverId: string;
    receiverName: string;
    message: string;
    proposedExchange: string;
  }) => {
    const sender = currentUser || INITIAL_USERS[0];
    const newRequest: ContactExchangeRequest = {
      id: `req-${Date.now()}`,
      publicationId: data.publicationId,
      publicationTitle: data.publicationTitle,
      publicationCategory: data.publicationCategory,
      senderId: sender.id,
      senderName: sender.name,
      senderEmail: sender.email,
      senderCareer: sender.career,
      senderCampus: sender.campus,
      senderPhone: sender.phone || '+51 900 000 000',
      receiverId: data.receiverId,
      receiverName: data.receiverName,
      message: data.message,
      proposedExchange: data.proposedExchange,
      status: 'pendiente',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    setRequests((prev) => [newRequest, ...prev]);

    setPublications((prev) =>
      prev.map((p) =>
        p.id === data.publicationId ? { ...p, contactCount: p.contactCount + 1 } : p
      )
    );

    try {
      confetti({ particleCount: 40, spread: 50 });
    } catch {}
  };

  const updateRequestStatus = (
    requestId: string,
    status: ContactExchangeRequest['status']
  ) => {
    setRequests((prev) =>
      prev.map((r) => (r.id === requestId ? { ...r, status } : r))
    );
  };

  const reportPublication = (data: {
    publicationId: string;
    publicationTitle: string;
    reason: PlagiarismReport['reason'];
    details: string;
  }) => {
    const reporter = currentUser || INITIAL_USERS[0];
    const newReport: PlagiarismReport = {
      id: `rep-${Date.now()}`,
      publicationId: data.publicationId,
      publicationTitle: data.publicationTitle,
      reporterName: reporter.name,
      reporterEmail: reporter.email,
      reason: data.reason,
      details: data.details,
      status: 'pendiente',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setReports((prev) => [newReport, ...prev]);
  };

  const resolveReport = (reportId: string, newStatus: PlagiarismReport['status']) => {
    setReports((prev) =>
      prev.map((rep) => (rep.id === reportId ? { ...rep, status: newStatus } : rep))
    );
  };

  const resetDatabase = () => {
    setPublications(INITIAL_PUBLICATIONS);
    setUsers(INITIAL_USERS);
    setCurrentUserId(INITIAL_USERS[0].id);
    setIsLoggedIn(true);
    setRequests(INITIAL_REQUESTS);
    setReports(INITIAL_REPORTS);
    setFilter(DEFAULT_FILTER);
  };

  return (
    <ExchangeContext.Provider
      value={{
        publications,
        users,
        currentUser,
        isLoggedIn,
        requests,
        reports,
        filter,
        setFilter,
        selectedPublication,
        setSelectedPublication,
        isCreateModalOpen,
        setIsCreateModalOpen,
        isContactModalOpen,
        setIsContactModalOpen,
        isRequestsDrawerOpen,
        setIsRequestsDrawerOpen,
        isAdminModalOpen,
        setIsAdminModalOpen,
        isProjectInfoModalOpen,
        setIsProjectInfoModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isCreatorOrAdmin,
        isOwner,
        addPublication,
        updatePublicationStatus,
        addReview,
        sendContactRequest,
        updateRequestStatus,
        reportPublication,
        resolveReport,
        loginUser,
        switchUser,
        logoutUser,
        registerUser,
        createUserByAdmin,
        updateUserRole,
        deleteUser,
        resetDatabase,
      }}
    >
      {children}
    </ExchangeContext.Provider>
  );
};

export function useExchange() {
  const context = useContext(ExchangeContext);
  if (!context) {
    throw new Error('useExchange must be used within an ExchangeProvider');
  }
  return context;
}
