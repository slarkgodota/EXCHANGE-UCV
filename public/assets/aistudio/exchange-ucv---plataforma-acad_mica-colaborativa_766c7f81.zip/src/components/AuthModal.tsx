import React, { useState } from 'react';
import {
  X,
  UserCheck,
  Lock,
  Mail,
  ShieldCheck,
  ArrowRight,
  Info,
} from 'lucide-react';
import { useExchange } from '../context/ExchangeContext';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    loginUser,
  } = useExchange();

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const emailTrimmed = loginEmail.trim();
    if (!emailTrimmed) {
      setLoginError('Por favor ingresa tu correo institucional.');
      return;
    }

    const success = loginUser(emailTrimmed);
    if (!success) {
      setLoginError(
        'Correo institucional no registrado en la base de datos de Exchange UCV. La creación y activación de cuentas es gestionada exclusivamente por los administradores y creadores del Grupo 5.'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
        {/* Official UCV Header Banner */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-950 via-[#182038] to-[#2c0e14] text-white border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white p-1.5 rounded-xl shadow-md">
              <img
                src="/assets/logo_ucv_oficial.png"
                alt="Universidad César Vallejo"
                className="h-7 w-auto object-contain"
              />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                Acceso a Exchange UCV
              </h2>
              <p className="text-[11px] text-slate-300">
                Plataforma Académica Universitaria • Perú
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Cerrar ventana"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Strictly login form with institutional notice */}
        <div className="p-6 overflow-y-auto space-y-5 max-h-[75vh]">
          {/* Institutional Access Notice: Public registration is restricted to Admins */}
          <div className="p-3.5 bg-amber-50/90 border border-amber-200 rounded-2xl flex items-start gap-3 text-xs text-amber-900 leading-relaxed shadow-xs">
            <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="block text-amber-950 font-bold">
                Acceso y Registro Restringido
              </strong>
              <p className="text-[11px] text-amber-800">
                Por políticas de autenticación y verificación universitaria, <strong>los nuevos estudiantes y docentes no pueden auto-registrarse</strong>. Las cuentas son habilitadas y administradas directamente por los fundadores del <strong>Grupo 5</strong> y los administradores autorizados.
              </p>
            </div>
          </div>

          {loginError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs leading-relaxed">
              {loginError}
            </div>
          )}

          {/* Login with Email Form */}
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5 text-xs">
                Correo Institucional UCV:
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="ejemplo@ucvvirtual.edu.pe"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-red-500/50 focus:border-red-500 focus:outline-none transition-all shadow-xs"
                  required
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Ingresa con tu correo institucional habilitado en el padrón
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5 text-xs">
                Contraseña Institucional:
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="password"
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-red-500/50 focus:border-red-500 focus:outline-none transition-all shadow-xs"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 active:scale-[0.99] text-white font-bold text-xs shadow-md shadow-red-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserCheck className="w-4 h-4" />
              Iniciar Sesión Institucional
            </button>
          </form>

          {/* Institutional Trust Badging */}
          <div className="pt-3 border-t border-slate-100 space-y-2">
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 text-[11px] text-slate-600 flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              <p>
                Base de datos verificada de la Universidad César Vallejo. Los administradores gestionan los permisos y altas desde el Panel de Administración.
              </p>
            </div>
          </div>
        </div>

        {/* Footer: Explore as guest */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Universidad César Vallejo</span>
          <button
            type="button"
            onClick={() => setIsAuthModalOpen(false)}
            className="text-slate-700 hover:text-red-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
          >
            Continuar como invitado y explorar <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
