import React, { useState } from 'react';
import { X, UserCheck, Plus, BadgeCheck, Shield, GraduationCap, Building } from 'lucide-react';
import { useExchange } from '../context/ExchangeContext';
import { CareerType, CampusType } from '../types/exchange';

const CAREERS: CareerType[] = [
  'Ingeniería Civil',
  'Ingeniería de Sistemas',
  'Medicina Humana',
  'Derecho',
  'Psicología',
  'Administración',
  'Arquitectura',
  'Contabilidad',
  'Ciencias de la Comunicación',
  'General / Interdisciplinario',
];

const CAMPUSES: CampusType[] = [
  'Lima Norte',
  'Lima Este',
  'Lima Ate',
  'Callao',
  'Trujillo',
  'Piura',
  'Chiclayo',
  'Tarapoto',
  'Chimbote',
  'Huaraz',
  'Chepén',
  'Moyobamba',
];

export const UserSwitcherModal: React.FC = () => {
  const {
    isUserSwitcherOpen,
    setIsUserSwitcherOpen,
    users,
    currentUser,
    switchUser,
    registerUser,
  } = useExchange();

  const [mode, setMode] = useState<'switch' | 'register'>('switch');

  // New user registration fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [career, setCareer] = useState<CareerType>('Ingeniería Civil');
  const [campus, setCampus] = useState<CampusType>('Moyobamba');
  const [cycle, setCycle] = useState('Ciclo VI');
  const [phone, setPhone] = useState('+51 9');
  const [bio, setBio] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isUserSwitcherOpen) return null;

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Por favor ingresa tu nombre completo.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Ingresa un correo institucional válido (ej. tu_usuario@ucvvirtual.edu.pe).');
      return;
    }

    registerUser({
      name: name.trim(),
      email: email.trim(),
      role: 'student',
      career,
      campus,
      cycle,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80',
      verified: true,
      bio: bio.trim() || `Estudiante de ${career} en la UCV sede ${campus}.`,
      phone: phone.trim(),
    });

    setIsUserSwitcherOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="bg-white p-1 rounded-lg">
              <img
                src="/assets/logo_ucv_alt.png"
                alt="UCV"
                className="h-6 w-auto object-contain"
              />
            </div>
            <div>
              <h3 className="font-bold text-sm">Padrón de Estudiantes UCV • Nivel Nacional</h3>
              <p className="text-[11px] text-slate-300">Accede o regístrate con tu sede UCV</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsUserSwitcherOpen(false)}
            className="p-1 rounded-full text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50">
          <button
            type="button"
            onClick={() => setMode('switch')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-all ${
              mode === 'switch'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Cuentas Verificadas (1-Click)
          </button>

          <button
            type="button"
            onClick={() => setMode('register')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-all flex items-center justify-center gap-1 ${
              mode === 'register'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            Crear Nueva Cuenta
          </button>
        </div>

        {/* Content */}
        {mode === 'switch' ? (
          <div className="p-5 space-y-3 max-h-96 overflow-y-auto">
            <p className="text-xs text-slate-500">
              Selecciona cualquier perfil para interactuar, publicar o evaluar como ese estudiante:
            </p>

            <div className="space-y-2">
              {users.map((user) => {
                const isSelected = user.id === currentUser.id;
                return (
                  <button
                    key={user.id}
                    type="button"
                    onClick={() => {
                      switchUser(user.id);
                      setIsUserSwitcherOpen(false);
                    }}
                    className={`w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-red-50/80 border-red-500 ring-2 ring-red-500/20'
                        : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <strong className="text-xs text-slate-900 truncate">
                            {user.name}
                          </strong>
                          {user.verified && <BadgeCheck className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">
                          {user.career} • Sede {user.campus}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                          user.role === 'admin'
                            ? 'bg-purple-100 text-purple-800'
                            : user.role === 'docente'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {user.role}
                      </span>
                      {isSelected && (
                        <p className="text-[10px] text-red-600 font-bold mt-1">Activo</p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <form onSubmit={handleRegister} className="p-5 space-y-4 text-xs">
            {error && (
              <div className="p-3 bg-red-50 text-red-800 border border-red-200 rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="block font-bold text-slate-700 mb-1">Nombre Completo:</label>
              <input
                type="text"
                placeholder="Ej. Juan Pérez García"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Correo Institucional UCV:
              </label>
              <input
                type="email"
                placeholder="ejemplo@ucvvirtual.edu.pe"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-slate-200"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Carrera:</label>
                <select
                  value={career}
                  onChange={(e) => setCareer(e.target.value as CareerType)}
                  className="w-full p-2 rounded-xl border border-slate-200 bg-white"
                >
                  {CAREERS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Sede UCV:</label>
                <select
                  value={campus}
                  onChange={(e) => setCampus(e.target.value as CampusType)}
                  className="w-full p-2 rounded-xl border border-slate-200 bg-white"
                >
                  {CAMPUSES.map((c) => (
                    <option key={c} value={c}>
                      Sede {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Ciclo:</label>
                <select
                  value={cycle}
                  onChange={(e) => setCycle(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-200 bg-white"
                >
                  <option value="Ciclo I">Ciclo I</option>
                  <option value="Ciclo II">Ciclo II</option>
                  <option value="Ciclo III">Ciclo III</option>
                  <option value="Ciclo IV">Ciclo IV</option>
                  <option value="Ciclo V">Ciclo V</option>
                  <option value="Ciclo VI">Ciclo VI</option>
                  <option value="Ciclo VII">Ciclo VII</option>
                  <option value="Ciclo VIII">Ciclo VIII</option>
                  <option value="Ciclo IX">Ciclo IX</option>
                  <option value="Ciclo X">Ciclo X</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Teléfono / WhatsApp:</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2 rounded-xl border border-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Biografía o especialidad:</label>
              <input
                type="text"
                placeholder="Ej. Interesado en cálculo y diseño estructural..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-2 rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setMode('switch')}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
              >
                Volver
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-red-600 text-white font-bold hover:bg-red-700"
              >
                Registrar y Acceder
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
