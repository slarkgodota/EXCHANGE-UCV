import React, { useState } from 'react';
import {
  X,
  Shield,
  Users,
  FileText,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Download,
  RotateCcw,
  Star,
  Search,
  BadgeCheck,
  Building,
  Lock,
  UserPlus,
  ShieldAlert,
  ShieldCheck,
  Crown,
  Trash2,
  GraduationCap,
  Sparkles,
} from 'lucide-react';
import { useExchange, CREATOR_EMAILS } from '../context/ExchangeContext';
import { calculateAdminMetrics, validateAdminCreateUser, canModifyRole } from '../utils/exchangeLogic';
import { CareerType, CampusType } from '../types/exchange';

const CAREERS: CareerType[] = [
  'Ingeniería Civil',
  'Ingeniería de Sistemas',
  'Medicina Humana',
  'Derecho',
  'Psicología',
  'Administración',
  'Arquitectura',
  'Contabilidad',
  'Ciencias de la Comunicación',
  'General / Interdisciplinario',
];

const CAMPUSES: CampusType[] = [
  'Lima Norte',
  'Lima Este',
  'Lima Ate',
  'Callao',
  'Trujillo',
  'Piura',
  'Chiclayo',
  'Tarapoto',
  'Moyobamba',
  'Chimbote',
  'Huaraz',
  'Chepén',
  'Arequipa',
];

export const AdminPanelModal: React.FC = () => {
  const {
    isAdminModalOpen,
    setIsAdminModalOpen,
    publications,
    users,
    requests,
    reports,
    updatePublicationStatus,
    resolveReport,
    resetDatabase,
    isCreatorOrAdmin,
    isOwner,
    setIsAuthModalOpen,
    currentUser,
    createUserByAdmin,
    updateUserRole,
    deleteUser,
  } = useExchange();

  const [activeTab, setActiveTab] = useState<'kpis' | 'publicaciones' | 'reportes' | 'usuarios'>('kpis');
  const [searchTerm, setSearchTerm] = useState('');
  const [resetConfirm, setResetConfirm] = useState(false);

  // New user form state inside Admin panel
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState<'student' | 'docente' | 'admin'>('student');
  const [newUserCareer, setNewUserCareer] = useState<CareerType>('Ingeniería Civil');
  const [newUserCampus, setNewUserCampus] = useState<CampusType>('Lima Norte');
  const [newUserCycle, setNewUserCycle] = useState('Ciclo V');
  const [newUserPhone, setNewUserPhone] = useState('+51 9');
  const [newUserBio, setNewUserBio] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Filter users inside Admin panel
  const [userSearchTerm, setUserSearchTerm] = useState('');

  if (!isAdminModalOpen) return null;

  // Security guard: Only creators and administrators can access the panel
  if (!isCreatorOrAdmin) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
        <div className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl border border-slate-200 overflow-hidden p-6 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto shadow-inner">
            <Lock className="w-7 h-7" />
          </div>

          <div className="space-y-1.5">
            <h3 className="text-lg font-bold text-slate-900">
              Acceso Exclusivo para Administradores
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              El panel de administración y control está reservado exclusivamente para los creadores de Grupo 5 y los usuarios a quienes se les ha otorgado permisos de administrador.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-[11px] text-slate-600">
            Usuario actual: <strong className="text-slate-800">{currentUser ? currentUser.name : 'Invitado / No autenticado'}</strong>
            <br />
            <span className="text-slate-400">Rol: {currentUser ? currentUser.role : 'Sin sesión activa'}</span>
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setIsAdminModalOpen(false);
                setIsAuthModalOpen(true);
              }}
              className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/20 transition-colors cursor-pointer"
            >
              Iniciar Sesión con Cuenta Autorizada
            </button>
            <button
              type="button"
              onClick={() => setIsAdminModalOpen(false)}
              className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors cursor-pointer"
            >
              Regresar a la Plataforma
            </button>
          </div>
        </div>
      </div>
    );
  }

  const metrics = calculateAdminMetrics(publications, users, requests, reports);

  const handleExportDB = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      institution: 'Universidad César Vallejo - Perú (Nacional)',
      project: 'Exchange UCV - Grupo 5',
      metrics,
      publications,
      users,
      requests,
      reports,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `exchange_ucv_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const validation = validateAdminCreateUser({
      name: newUserName,
      email: newUserEmail,
      role: newUserRole,
      career: newUserCareer,
      campus: newUserCampus,
      existingEmails: users.map((u) => u.email),
    });

    if (validation) {
      setFormError(validation);
      return;
    }

    const created = createUserByAdmin({
      name: newUserName.trim(),
      email: newUserEmail.trim().toLowerCase(),
      role: newUserRole,
      career: newUserCareer,
      campus: newUserCampus,
      cycle: newUserCycle,
      phone: newUserPhone.trim(),
      bio: newUserBio.trim(),
    });

    setToastMessage(`Usuario "${created.name}" registrado con éxito. Se le asignó el rol de ${created.role.toUpperCase()}.`);
    setShowCreateForm(false);
    setNewUserName('');
    setNewUserEmail('');
    setNewUserPhone('+51 9');
    setNewUserBio('');

    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleToggleAdminRole = (userId: string, currentRole: string, userName: string, userEmail: string) => {
    if (!canModifyRole(userEmail, CREATOR_EMAILS)) {
      setToastMessage(`Los permisos del fundador (${userName}) están protegidos institucionalmente.`);
      return;
    }

    const newRole = currentRole === 'admin' ? 'student' : 'admin';
    updateUserRole(userId, newRole);
    setToastMessage(
      newRole === 'admin'
        ? `✅ Permisos de Administrador concedidos a ${userName}. Ahora tiene acceso total al panel.`
        : `ℹ️ Se revocaron los permisos de administrador a ${userName}. Regresó a rol Estudiante.`
    );

    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleToggleDocenteRole = (userId: string, currentRole: string, userName: string, userEmail: string) => {
    if (!canModifyRole(userEmail, CREATOR_EMAILS)) return;
    const newRole = currentRole === 'docente' ? 'student' : 'docente';
    updateUserRole(userId, newRole);
    setToastMessage(`Rol actualizado para ${userName}: ahora es ${newRole === 'docente' ? 'Docente / Catedrático' : 'Estudiante'}.`);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  const handleDeleteUser = (userId: string, userName: string, userEmail: string) => {
    if (!canModifyRole(userEmail, CREATOR_EMAILS)) {
      setToastMessage(`No se puede dar de baja a los fundadores del Grupo 5.`);
      return;
    }

    if (window.confirm(`¿Estás seguro de dar de baja al usuario "${userName}" (${userEmail}) de la base de datos?`)) {
      const ok = deleteUser(userId);
      if (ok) {
        setToastMessage(`Usuario ${userName} eliminado del padrón.`);
        setTimeout(() => setToastMessage(null), 3500);
      }
    }
  };

  const filteredUsers = users.filter((u) => {
    if (!userSearchTerm.trim()) return true;
    const q = userSearchTerm.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.career.toLowerCase().includes(q) ||
      u.campus.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600/30 border border-red-500/40 flex items-center justify-center text-red-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Panel de Control & Administración Exchange UCV</h3>
                <span className="text-[10px] bg-red-600/50 text-red-200 px-2 py-0.5 rounded-full font-mono uppercase">
                  Nacional • Perú
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Supervisión institucional, padrón de usuarios, control de roles y ética académica UCV
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportDB}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors cursor-pointer"
              title="Descargar copia de seguridad en JSON"
            >
              <Download className="w-3.5 h-3.5" />
              Exportar DB
            </button>

            <button
              type="button"
              onClick={() => setIsAdminModalOpen(false)}
              className="p-1 rounded-full text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Toast Notification */}
        {toastMessage && (
          <div className="bg-emerald-600 text-white px-6 py-2.5 text-xs font-semibold flex items-center justify-between animate-fadeIn shadow-inner">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>{toastMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setToastMessage(null)}
              className="text-white/80 hover:text-white text-xs font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 gap-2 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('kpis')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'kpis'
                ? 'border-red-600 text-red-600 bg-white rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            Métricas y Resumen General
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('usuarios')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'usuarios'
                ? 'border-red-600 text-red-600 bg-white rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            Padrón & Roles de Usuario ({users.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('publicaciones')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'publicaciones'
                ? 'border-red-600 text-red-600 bg-white rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            Publicaciones ({publications.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reportes')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'reportes'
                ? 'border-red-600 text-red-600 bg-white rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            Control de Plagio & Reportes ({reports.length})
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: KPIS */}
          {activeTab === 'kpis' && (
            <div className="space-y-6">
              {/* KPI Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase">Usuarios Registrados</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{metrics.totalUsers}</div>
                  <p className="text-[11px] text-emerald-600 font-medium mt-1">Grupo 5 & Habilitados</p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase">Publicaciones Activas</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{metrics.totalPublications}</div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    {metrics.materialsCount} Mat. / {metrics.knowledgeCount} Con. / {metrics.researchCount} Inv.
                  </p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase">Intercambios Coordinados</span>
                  <div className="text-2xl font-black text-slate-900 mt-1">{metrics.totalExchanges}</div>
                  <p className="text-[11px] text-blue-600 font-medium mt-1">Colaboraciones entre pares</p>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase">Satisfacción Promedio</span>
                  <div className="text-2xl font-black text-amber-500 mt-1 flex items-center gap-1">
                    {metrics.averageSatisfaction.toFixed(1)} <Star className="w-5 h-5 fill-amber-400" />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">Calificaciones de 5 estrellas</p>
                </div>
              </div>

              {/* Real Project Context (PDF Authors) */}
              <div className="p-5 bg-gradient-to-br from-red-50 to-rose-50 border border-red-200 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-red-950 text-sm flex items-center gap-2">
                    <Shield className="w-4 h-4 text-red-600" />
                    Equipo Fundador del Proyecto Exchange UCV (Grupo 5)
                  </h4>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-red-200 text-red-900 font-bold">
                    Autores Registrados en DB
                  </span>
                </div>
                <p className="text-xs text-red-800 leading-relaxed">
                  Conforme a la documentación oficial del proyecto (Grupo 5), las cuentas fundadoras tienen permisos raíz para crear usuarios, conceder privilegios de administrador a estudiantes y docentes de cualquier sede, y velar por la integridad académica.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 pt-1 text-xs">
                  <div className="bg-white/80 p-2.5 rounded-xl border border-red-200 text-slate-800">
                    <div className="flex items-center justify-between">
                      <strong className="block text-red-900">Michael Jefferson Delgado Cerdán</strong>
                      <Crown className="w-3.5 h-3.5 text-amber-500" />
                    </div>
                    <span className="text-[11px] text-slate-500">mdelgadoc@ucvvirtual.edu.pe</span>
                    <span className="block text-[10px] text-red-600 font-bold mt-0.5">Dueño / Fundador</span>
                  </div>
                  <div className="bg-white/80 p-2.5 rounded-xl border border-red-200 text-slate-800">
                    <div className="flex items-center justify-between">
                      <strong className="block text-red-900">José Roly Gonzalez Guevara</strong>
                      <Crown className="w-3.5 h-3.5 text-amber-500" />
                    </div>
                    <span className="text-[11px] text-slate-500">jgonzalezg@ucvvirtual.edu.pe</span>
                    <span className="block text-[10px] text-red-600 font-bold mt-0.5">Creador / Fundador</span>
                  </div>
                  <div className="bg-white/80 p-2.5 rounded-xl border border-red-200 text-slate-800">
                    <div className="flex items-center justify-between">
                      <strong className="block text-red-900">Michael Cristofer Grandez Acosta</strong>
                      <Crown className="w-3.5 h-3.5 text-amber-500" />
                    </div>
                    <span className="text-[11px] text-slate-500">mgrandeza@ucvvirtual.edu.pe</span>
                    <span className="block text-[10px] text-red-600 font-bold mt-0.5">Creador / Fundador</span>
                  </div>
                </div>
              </div>

              {/* Maintenance Tools */}
              <div className="border border-slate-200 p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-xs text-slate-900">Mantenimiento de Base de Datos</h5>
                  <p className="text-[11px] text-slate-500">
                    Restaura los datos iniciales estrictamente con los autores del Grupo 5.
                  </p>
                </div>

                {resetConfirm ? (
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setResetConfirm(false)}
                      className="px-3 py-1.5 text-xs text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        resetDatabase();
                        setResetConfirm(false);
                        setToastMessage('Base de datos restaurada al padrón del Grupo 5.');
                      }}
                      className="px-3 py-1.5 text-xs bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 cursor-pointer"
                    >
                      Confirmar Reinicio
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setResetConfirm(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                    Reiniciar Base de Datos
                  </button>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: PADRÓN DE USUARIOS Y GESTIÓN DE ROLES / PERMISOS */}
          {activeTab === 'usuarios' && (
            <div className="space-y-5">
              {/* Top Controls: Search + Button to create user */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder="Buscar por nombre, correo, carrera o sede..."
                    value={userSearchTerm}
                    onChange={(e) => setUserSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-red-500/50 focus:outline-none"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setShowCreateForm(!showCreateForm)}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold shadow-md shadow-red-600/20 transition-all cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{showCreateForm ? 'Cerrar Formulario' : '+ Registrar Estudiante / Docente'}</span>
                </button>
              </div>

              {/* Informative banner on account governance */}
              <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-3.5 text-xs text-slate-600 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <strong className="text-slate-900 block font-bold">
                    Control de Permisos y Cuentas UCV
                  </strong>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Como administrador, puedes registrar nuevas cuentas institucionales para estudiantes y docentes que lo soliciten, así como <strong>otorgar o revocar permisos de administrador</strong> a cualquier usuario para que también pueda gestionar la plataforma. Los fundadores del Grupo 5 tienen permisos permanentes.
                  </p>
                </div>
              </div>

              {/* Create User Form Drawer/Card */}
              {showCreateForm && (
                <div className="p-5 bg-gradient-to-br from-slate-50 to-red-50/30 rounded-2xl border-2 border-red-200/80 shadow-md space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-red-100 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-red-100 text-red-600">
                        <UserPlus className="w-4 h-4" />
                      </div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        Registrar y Habilitar Nuevo Usuario en DB
                      </h4>
                    </div>
                    <span className="text-[11px] text-slate-500">
                      Acceso gestionado por administración
                    </span>
                  </div>

                  {formError && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs">
                      {formError}
                    </div>
                  )}

                  <form onSubmit={handleCreateUserSubmit} className="space-y-4 text-xs">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Nombres y Apellidos:
                        </label>
                        <input
                          type="text"
                          placeholder="Ej. Luis Alberto Sánchez"
                          value={newUserName}
                          onChange={(e) => setNewUserName(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50 focus:outline-none"
                          required
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Correo Institucional UCV:
                        </label>
                        <input
                          type="email"
                          placeholder="ejemplo@ucvvirtual.edu.pe"
                          value={newUserEmail}
                          onChange={(e) => setNewUserEmail(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50 focus:outline-none"
                          required
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          El usuario usará este correo para iniciar sesión.
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Rol a Otorgar:
                        </label>
                        <select
                          value={newUserRole}
                          onChange={(e) => setNewUserRole(e.target.value as 'student' | 'docente' | 'admin')}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50"
                        >
                          <option value="student">Estudiante UCV</option>
                          <option value="docente">Docente / Catedrático</option>
                          <option value="admin">Administrador (Permisos Totales)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Carrera Profesional:
                        </label>
                        <select
                          value={newUserCareer}
                          onChange={(e) => setNewUserCareer(e.target.value as CareerType)}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50"
                        >
                          {CAREERS.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Sede UCV:
                        </label>
                        <select
                          value={newUserCampus}
                          onChange={(e) => setNewUserCampus(e.target.value as CampusType)}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50"
                        >
                          {CAMPUSES.map((camp) => (
                            <option key={camp} value={camp}>
                              Sede {camp}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Ciclo o Grado Académico:
                        </label>
                        <input
                          type="text"
                          placeholder={newUserRole === 'docente' ? 'Catedrático / Magíster' : 'Ciclo V'}
                          value={newUserCycle}
                          onChange={(e) => setNewUserCycle(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-slate-700 mb-1">
                          Teléfono / WhatsApp:
                        </label>
                        <input
                          type="text"
                          placeholder="+51 987 654 321"
                          value={newUserPhone}
                          onChange={(e) => setNewUserPhone(e.target.value)}
                          className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">
                        Notas / Especialidad:
                      </label>
                      <input
                        type="text"
                        placeholder="Ej. Interés en estructuras, tutorías, semilleros..."
                        value={newUserBio}
                        onChange={(e) => setNewUserBio(e.target.value)}
                        className="w-full p-2.5 rounded-xl border border-slate-200 bg-white focus:ring-2 focus:ring-red-500/50"
                      />
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                      <button
                        type="button"
                        onClick={() => setShowCreateForm(false)}
                        className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
                      >
                        Cancelar
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold shadow-md shadow-red-600/20 transition-all cursor-pointer"
                      >
                        Guardar y Habilitar en DB
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Users Cards with Role Actions */}
              <div className="space-y-3">
                <div className="text-xs text-slate-500 flex items-center justify-between">
                  <span>Padrón de usuarios registrados: <strong>{filteredUsers.length}</strong></span>
                  <span className="text-[11px] text-slate-400">
                    Cambios de rol se reflejan de inmediato en tiempo real
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {filteredUsers.map((u) => {
                    const isFounder = CREATOR_EMAILS.includes(u.email.toLowerCase().trim());
                    const canEdit = canModifyRole(u.email, CREATOR_EMAILS);

                    return (
                      <div
                        key={u.id}
                        className={`p-4 rounded-2xl border transition-all text-xs flex flex-col justify-between gap-3 ${
                          isFounder
                            ? 'bg-gradient-to-br from-red-50/70 via-white to-rose-50/40 border-red-200 shadow-xs'
                            : u.role === 'admin'
                            ? 'bg-purple-50/50 border-purple-200 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {/* Top: Avatar & User Identity */}
                        <div className="flex items-start gap-3">
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <strong className="text-slate-900 truncate font-bold text-sm">
                                {u.name}
                              </strong>
                              {u.verified && (
                                <BadgeCheck className="w-4 h-4 text-blue-600 shrink-0" title="Verificado UCV" />
                              )}
                            </div>

                            <p className="text-[11px] text-slate-500 truncate mt-0.5 font-mono">
                              {u.email}
                            </p>

                            <p className="text-[11px] text-slate-600 mt-1">
                              {u.career} • Sede {u.campus}
                            </p>

                            <span className="text-[10px] text-slate-400">
                              {u.cycle} {u.phone ? `• ${u.phone}` : ''}
                            </span>
                          </div>

                          {/* Role Badge */}
                          <div className="shrink-0 text-right">
                            {isFounder ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-black px-2.5 py-1 rounded-full bg-red-600 text-white uppercase shadow-xs">
                                <Crown className="w-3 h-3 text-amber-300" />
                                Fundador G5
                              </span>
                            ) : u.role === 'admin' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 uppercase">
                                <Shield className="w-3 h-3 text-purple-600" />
                                Admin
                              </span>
                            ) : u.role === 'docente' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 uppercase">
                                <GraduationCap className="w-3 h-3 text-amber-600" />
                                Docente
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 uppercase">
                                Estudiante
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions for role management */}
                        <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                          {isFounder ? (
                            <span className="text-[11px] font-medium text-red-700 italic">
                              Permisos Raíz • Creador del Proyecto
                            </span>
                          ) : (
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {/* Toggle Admin Privilege Button */}
                              {u.role === 'admin' ? (
                                <button
                                  type="button"
                                  onClick={() => handleToggleAdminRole(u.id, u.role, u.name, u.email)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold transition-colors cursor-pointer"
                                  title="Revocar permisos de administrador"
                                >
                                  <ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
                                  Quitar Admin
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleToggleAdminRole(u.id, u.role, u.name, u.email)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-900 text-[11px] font-bold transition-colors cursor-pointer"
                                  title="Otorgar permisos de administrador para monitorear y gestionar la plataforma"
                                >
                                  <Crown className="w-3.5 h-3.5 text-purple-700" />
                                  Dar Permisos Admin
                                </button>
                              )}

                              {/* Toggle between Docente and Student */}
                              <button
                                type="button"
                                onClick={() => handleToggleDocenteRole(u.id, u.role, u.name, u.email)}
                                className="px-2 py-1 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-600 text-[11px] transition-colors cursor-pointer"
                              >
                                {u.role === 'docente' ? 'Cambiar a Estudiante' : 'Cambiar a Docente'}
                              </button>
                            </div>
                          )}

                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => handleDeleteUser(u.id, u.name, u.email)}
                              className="p-1 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors ml-auto cursor-pointer"
                              title="Dar de baja de la base de datos"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PUBLICACIONES */}
          {activeTab === 'publicaciones' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700">Moderación y Estado de Recursos</span>
                <span className="text-slate-500">Mostrando {publications.length} registros</span>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold">
                    <tr>
                      <th className="p-3">Título / Curso</th>
                      <th className="p-3">Carrera</th>
                      <th className="p-3">Autor</th>
                      <th className="p-3">Rating</th>
                      <th className="p-3">Estado</th>
                      <th className="p-3 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {publications.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50">
                        <td className="p-3 font-medium text-slate-900 max-w-[240px]">
                          <div className="font-bold truncate">{p.title}</div>
                          <div className="text-[11px] text-slate-500">{p.course} • {p.category}</div>
                        </td>
                        <td className="p-3 text-slate-600">{p.career}</td>
                        <td className="p-3 text-slate-700">
                          <div>{p.author.name}</div>
                          <div className="text-[10px] text-slate-400">Sede {p.author.campus}</div>
                        </td>
                        <td className="p-3 font-semibold text-amber-600">
                          {p.ratingAverage.toFixed(1)}★ ({p.reviews.length})
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              p.status === 'destacado'
                                ? 'bg-amber-100 text-amber-800'
                                : p.status === 'aprobado'
                                ? 'bg-emerald-100 text-emerald-800'
                                : p.status === 'reportado'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>
                        <td className="p-3 text-right space-x-1">
                          <button
                            type="button"
                            onClick={() =>
                              updatePublicationStatus(
                                p.id,
                                p.status === 'destacado' ? 'aprobado' : 'destacado'
                              )
                            }
                            className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-semibold cursor-pointer"
                          >
                            {p.status === 'destacado' ? 'Desmarcar' : 'Destacar'}
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              updatePublicationStatus(
                                p.id,
                                p.status === 'reportado' ? 'aprobado' : 'reportado'
                              )
                            }
                            className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-700 rounded text-[11px] font-semibold cursor-pointer"
                          >
                            {p.status === 'reportado' ? 'Reactivar' : 'Pausar'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: REPORTES & PLAGIO */}
          {activeTab === 'reportes' && (
            <div className="space-y-4">
              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 text-xs text-amber-900 leading-relaxed">
                <strong>Supervisión de Plagio y Uso Responsable (Sección 10 del Proyecto Exchange UCV):</strong>
                <p className="mt-1">
                  Los materiales compartidos deben respetar los derechos de autor y servir para aprender, evitando el fraude o la copia.
                </p>
              </div>

              {reports.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  No hay reportes de plagio pendientes.
                </div>
              ) : (
                <div className="space-y-3">
                  {reports.map((rep) => (
                    <div
                      key={rep.id}
                      className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-red-600" />
                          <span>{rep.publicationTitle}</span>
                        </div>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            rep.status === 'resuelto'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {rep.status}
                        </span>
                      </div>

                      <p className="text-slate-600">
                        <strong>Motivo:</strong> {rep.reason.toUpperCase()} — {rep.details}
                      </p>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-400">
                        <span>Reportado por: {rep.reporterName} ({rep.reporterEmail}) • {rep.createdAt}</span>

                        {rep.status === 'pendiente' && (
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => resolveReport(rep.id, 'descartado')}
                              className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer"
                            >
                              Desestimar
                            </button>
                            <button
                              type="button"
                              onClick={() => resolveReport(rep.id, 'resuelto')}
                              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold cursor-pointer"
                            >
                              Marcar como Resuelto
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
