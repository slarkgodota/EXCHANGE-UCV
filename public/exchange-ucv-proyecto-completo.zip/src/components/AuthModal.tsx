import React, { useState } from 'react';
import {
  X,
  UserCheck,
  Lock,
  Mail,
  ShieldCheck,
  ArrowRight,
  Info,
  Eye,
  EyeOff,
  Crown,
  KeyRound,
} from 'lucide-react';
import { useExchange } from '../context/ExchangeContext';

const FOUNDER_ACCOUNTS = [
  {
    name: 'Michael Jefferson Delgado Cerdán',
    role: 'Dueño / Fundador / Admin',
    email: 'mdelgadoc@ucvvirtual.edu.pe',
    password: 'AdminExchange2026*',
    campus: 'Lima Norte',
  },
  {
    name: 'José Roly Gonzalez Guevara',
    role: 'Creador / Fundador / Admin',
    email: 'jgonzalezg@ucvvirtual.edu.pe',
    password: 'AdminExchange2026*',
    campus: 'Trujillo',
  },
  {
    name: 'Michael Cristofer Grandez Acosta',
    role: 'Creador / Fundador / Admin',
    email: 'mgrandeza@ucvvirtual.edu.pe',
    password: 'AdminExchange2026*',
    campus: 'Tarapoto',
  },
];

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    loginUser,
  } = useExchange();

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const emailTrimmed = loginEmail.trim();
    if (!emailTrimmed) {
      setLoginError('Por favor ingresa tu correo institucional.');
      return;
    }

    const success = loginUser(emailTrimmed, loginPassword);
    if (!success) {
      setLoginError(
        'Credenciales inválidas. Verifica tu correo institucional y contraseña (para los fundadores del Grupo 5 la contraseña es AdminExchange2026*).'
      );
    }
  };

  const handleQuickLogin = (email: string, pass: string) => {
    setLoginEmail(email);
    setLoginPassword(pass);
    loginUser(email, pass);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col">
        {/* Official UCV Header Banner */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-950 via-[#182038] to-[#2c0e14] text-white border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white p-1.5 rounded-xl shadow-md">
              <img
                src="/assets/logo_ucv_oficial.png"
                alt="Universidad César Vallejo"
                className="h-7 w-auto object-contain"
              />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                Acceso a Exchange UCV
              </h2>
              <p className="text-[11px] text-slate-300">
                Plataforma Académica Universitaria • Perú
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Cerrar ventana"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Strictly login form with institutional notice */}
        <div className="p-6 overflow-y-auto space-y-5 max-h-[75vh]">
          {/* Institutional Access Notice: Public registration is restricted to Admins */}
          <div className="p-3.5 bg-amber-50/90 border border-amber-200 rounded-2xl flex items-start gap-3 text-xs text-amber-900 leading-relaxed shadow-xs">
            <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="block text-amber-950 font-bold">
                Acceso y Registro Restringido
              </strong>
              <p className="text-[11px] text-amber-800">
                Por políticas de autenticación y verificación universitaria, <strong>los nuevos estudiantes y docentes no pueden auto-registrarse</strong>. Las cuentas son habilitadas y administradas directamente por los fundadores del <strong>Grupo 5</strong> y los administradores autorizados.
              </p>
            </div>
          </div>

          {loginError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs leading-relaxed">
              {loginError}
            </div>
          )}

          {/* Login with Email Form */}
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5 text-xs">
                Correo Institucional UCV:
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  placeholder="ejemplo@ucvvirtual.edu.pe"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full pl-10 pr-3.5 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-red-500/50 focus:border-red-500 focus:outline-none transition-all shadow-xs"
                  required
                />
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Ingresa con tu correo institucional habilitado en el padrón
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1.5 text-xs">
                Contraseña Institucional:
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-3 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-red-500/50 focus:border-red-500 focus:outline-none transition-all shadow-xs"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                  title={showPassword ? 'Ocultar contraseña' : 'Ver contraseña'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 active:scale-[0.99] text-white font-bold text-xs shadow-md shadow-red-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserCheck className="w-4 h-4" />
              Iniciar Sesión Institucional
            </button>
          </form>

          {/* Quick Founder Accounts List */}
          <div className="pt-2 border-t border-slate-100 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5 text-amber-500" />
                Cuentas de Administradores (Grupo 5)
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Click para autocompletar
              </span>
            </div>

            <div className="space-y-1.5">
              {FOUNDER_ACCOUNTS.map((acc) => (
                <div
                  key={acc.email}
                  className="p-2.5 rounded-xl border border-slate-200 bg-slate-50/80 hover:bg-red-50/50 hover:border-red-200 transition-colors flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <strong className="text-xs text-slate-900 truncate">
                        {acc.name.split(' ')[0]} {acc.name.split(' ')[1] || ''}
                      </strong>
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-red-100 text-red-700">
                        Admin
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono truncate">
                      {acc.email}
                    </div>
                    <div className="text-[10px] text-slate-600 flex items-center gap-1 mt-0.5">
                      <KeyRound className="w-3 h-3 text-slate-400" />
                      Clave: <code className="font-bold text-slate-800 bg-slate-200/80 px-1 rounded">{acc.password}</code>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleQuickLogin(acc.email, acc.password)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-red-600 text-white font-bold text-[10px] transition-colors shrink-0 cursor-pointer"
                  >
                    Ingresar
                  </button>
                </div>
              ))}
            </div>

            <p className="text-[10px] text-slate-500 italic text-center pt-1">
              Nota: Una vez dentro como Administrador, puedes crear nuevos correos y contraseñas desde el Panel de Administración.
            </p>
          </div>

          {/* Institutional Trust Badging */}
          <div className="pt-2 border-t border-slate-100">
            <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 text-[11px] text-slate-600 flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              <p>
                Base de datos verificada de la Universidad César Vallejo. Cuentas administradas por el Grupo 5.
              </p>
            </div>
          </div>
        </div>

        {/* Footer: Explore as guest */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Universidad César Vallejo</span>
          <button
            type="button"
            onClick={() => setIsAuthModalOpen(false)}
            className="text-slate-700 hover:text-red-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
          >
            Continuar como invitado y explorar <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
