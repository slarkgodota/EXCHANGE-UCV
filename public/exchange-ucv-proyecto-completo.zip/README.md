# 🎓 Exchange UCV - Plataforma Académica Colaborativa (Grupo 5)

Plataforma universitaria diseñada para estudiantes y docentes de la **Universidad César Vallejo (UCV)** para el intercambio ético de apuntes, resolución de dudas de laboratorio, asesorías entre pares y formación de equipos de investigación multidisciplinarios bajo la línea de **Responsabilidad Social Universitaria (RSU)** y el **Artículo 10 de Integridad Académica**.

---

## 👥 Cuentas de Acceso Oficiales (Administradores y Fundadores)

| Nombre | Rol | Correo Institucional | Contraseña | Sede |
| :--- | :--- | :--- | :--- | :--- |
| **Michael Jefferson Delgado Cerdán** | Dueño / Creador / Admin | `mdelgadoc@ucvvirtual.edu.pe` | `AdminExchange2026*` | Lima Norte |
| **José Roly Gonzalez Guevara** | Creador / Fundador / Admin | `jgonzalezg@ucvvirtual.edu.pe` | `AdminExchange2026*` | Trujillo |
| **Michael Cristofer Grandez Acosta** | Creador / Fundador / Admin | `mgrandeza@ucvvirtual.edu.pe` | `AdminExchange2026*` | Tarapoto |

> *Clave maestra universal alternativa: `Ucv2026*`*
> *Desde el Panel de Administración puedes crear nuevos usuarios, asignar roles y definir contraseñas personalizadas.*

---

## 💻 Cómo ejecutar el proyecto en tu PC (Con Internet y Sin Internet)

### Requisitos previos:
- Tener instalado [Node.js](https://nodejs.org/) (versión 18 o superior).

### Paso 1: Descargar y descomprimir
1. Descarga el archivo `.zip` del proyecto en tu computadora.
2. Descomprímelo en una carpeta de tu preferencia (ej. `C:\ExchangeUCV`).

### Paso 2: Instalar dependencias (se hace una sola vez con internet)
Abre la terminal o símbolo del sistema (CMD / PowerShell) en esa carpeta y escribe:
```bash
npm install
```

---

## 🌐 1. Uso CON INTERNET (Modo Completo)
Para iniciar la plataforma con todas las funciones en vivo, incluyendo el motor de auditoría con IA Gemini:
```bash
npm run dev
```
Abre tu navegador en: **`http://localhost:3000`**

---

## 📴 2. Uso SIN INTERNET (Modo Offline 100% Autónomo)

El proyecto incluye tecnología **Progressive Web App (PWA)** y **Service Worker (Workbox)** con precaché inteligente de recursos:

### Opción A: Como aplicación de escritorio instalada (Recomendado)
1. Abre la aplicación en tu navegador (Google Chrome o Edge) en `http://localhost:3000`.
2. En la barra de direcciones verás el ícono de **"Instalar Exchange UCV"** (o en el menú de los 3 puntos: *"Instalar aplicación"*).
3. Haz clic en **Instalar**.
4. ¡Listo! Se creará un acceso directo en tu Escritorio de Windows / Mac con el escudo de la UCV.
5. **Aunque no tengas conexión a internet ni WiFi**, haz doble clic en la aplicación:
   - Abrirá al instante sin conexión.
   - Toda la base de datos de apuntes, catálogo, valoraciones de 5 estrellas y usuarios se almacena en el almacenamiento local persistente de tu equipo.
   - El sistema mostrará el banner: *`Modo Sin Conexión (Offline) Activo`*.

### Opción B: Ejecución local sin conexión desde la terminal
Si estás sin internet en tu laptop, puedes iniciar el servidor local con:
```bash
npm run dev
```
o también compilar la versión estática ultra-rápida:
```bash
npm run build
npm run preview
```
Todos los scripts, estilos y componentes se cargarán directamente desde los archivos locales de tu disco duro sin necesidad de conectarse a la red.

---

## 🛡️ Características Principales
- **Auditoría de Originalidad con IA:** Evalúa la estructura formativa y previene el plagio conforme al Art. 10.
- **Tabla de Valoraciones de 5 Estrellas:** Reseñas verificadas de estudiantes de la UCV.
- **Gobernanza Institucional:** Panel Admin exclusivo para el Grupo 5 con control de usuarios y reportes.
- **Bandeja de Solicitudes:** Los datos de contacto solo se revelan cuando ambas partes aceptan el intercambio.
